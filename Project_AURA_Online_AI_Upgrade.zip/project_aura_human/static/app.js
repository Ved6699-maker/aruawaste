const $ = (id) => document.getElementById(id);
const messagesEl = $("messages");
let conversation = [];
let selectedMood = "Not sure";
let recognition = null;

const expressionInfo = {
  calm: ["☾", "Calm expression"],
  happy: ["☀", "Happy expression"],
  curious: ["✧", "Curious expression"],
  concerned: ["♡", "Concerned expression"],
  surprised: ["✦", "Surprised expression"]
};
const themes = {
  aurora: ["#b4a5ff", "#65c9da", "#e9c9ff"],
  ocean: ["#80c8ff", "#4fe0d0", "#b6e7ff"],
  rose: ["#f0a3c2", "#e8a2a2", "#ffe0ed"],
  forest: ["#91d5b1", "#55c5b7", "#c5f1d8"]
};

function setExpression(expression) {
  const safe = expressionInfo[expression] ? expression : "calm";
  $("avatar").dataset.expression = safe;
  $("expressionIcon").textContent = expressionInfo[safe][0];
  $("expressionText").textContent = expressionInfo[safe][1];
  $("expressionSelect").value = safe;
}
function addMessage(role, content, timestamp = "Just now") {
  const row = document.createElement("div");
  row.className = `message-row ${role === "user" ? "user-row" : "assistant-row"}`;
  const icon = document.createElement("div");
  icon.className = "mini-avatar";
  icon.textContent = role === "user" ? "You" : "✦";
  const wrap = document.createElement("div");
  wrap.className = "bubble-wrap";
  const sender = document.createElement("span");
  sender.className = "sender";
  sender.textContent = role === "user" ? "You" : $("nameInput").value.trim() || "Aura";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = content;
  const time = document.createElement("time");
  time.textContent = timestamp;
  wrap.append(sender, bubble, time);
  row.append(icon, wrap);
  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
function clearMessages() {
  messagesEl.replaceChildren();
  conversation = [];
  addMessage("assistant", `Hi, I'm ${$("nameInput").value.trim() || "Aura"}. I'm here to listen, think things through with you, or celebrate the good stuff. What would you like to talk about?`);
}
function updateTheme() {
  const vals = themes[$("styleSelect").value] || themes.aurora;
  document.documentElement.style.setProperty("--avatar1", vals[0]);
  document.documentElement.style.setProperty("--avatar2", vals[1]);
  document.documentElement.style.setProperty("--avatar3", vals[2]);
}
function applyName() {
  const name = $("nameInput").value.trim() || "Aura";
  $("companionTitle").textContent = name;
  $("welcomeSender").textContent = name;
}
function savePrefs() {
  const prefs = {
    name: $("nameInput").value.trim() || "Aura",
    style: $("styleSelect").value,
    personality: $("personalitySelect").value,
    expression: $("expressionSelect").value,
    gender: $("genderSelect").value
  };
  localStorage.setItem("auraPrefs", JSON.stringify(prefs));
  applyName();
  updateTheme();
  setExpression(prefs.expression);
  $("savePrefs").textContent = "Preferences saved ✓";
  setTimeout(() => $("savePrefs").textContent = "Save preferences on this device", 1600);
}
function loadPrefs() {
  try {
    const prefs = JSON.parse(localStorage.getItem("auraPrefs") || "{}");
    if (prefs.name) $("nameInput").value = prefs.name;
    if (prefs.style && themes[prefs.style]) $("styleSelect").value = prefs.style;
    if (prefs.personality) $("personalitySelect").value = prefs.personality;
    if (prefs.expression && expressionInfo[prefs.expression]) $("expressionSelect").value = prefs.expression;
    if (prefs.gender && ["feminine", "masculine", "androgynous"].includes(prefs.gender)) $("genderSelect").value = prefs.gender;
  } catch (_) {}
  applyName(); updateTheme(); setExpression($("expressionSelect").value); applyGender();
}
function applyGender() {
  $("avatar").dataset.gender = $("genderSelect").value;
}
function doAction(action) {
  const avatar = $("avatar");
  avatar.dataset.action = action;
  if (action === "listen") {
    $("expressionText").textContent = "Listening";
  }
  window.setTimeout(() => {
    if (avatar.dataset.action === action) avatar.dataset.action = "";
    if (action === "listen") setExpression($("expressionSelect").value);
  }, action === "listen" ? 5000 : 1800);
}
document.querySelectorAll("[data-action]").forEach(button => {
  button.addEventListener("click", () => doAction(button.dataset.action));
});
$("genderSelect").addEventListener("change", applyGender);
function inferExpression(text) {
  const t = text.toLowerCase();
  if (/(happy|excited|proud|great|finished|completed|thank you)/.test(t)) return "happy";
  if (/(sad|lonely|terrible|upset|hurt|cry|grief)/.test(t)) return "concerned";
  if (/(why|how|wonder|curious|what if)/.test(t)) return "curious";
  if (/(wow|unbelievable|surprise|amazing)/.test(t)) return "surprised";
  return "calm";
}
async function sendMessage() {
  const input = $("messageInput");
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  input.style.height = "auto";
  conversation.push({role: "user", content: text});
  addMessage("user", text);
  setExpression(inferExpression(text));
  $("typingStatus").textContent = "Thinking…";
  $("typingStatus").className = "typing";
  $("sendButton").disabled = true;
  try {
    const payload = {
      messages: conversation.slice(-20),
      mood: selectedMood,
      companion_name: $("nameInput").value.trim() || "Aura",
      personality: $("personalitySelect").value
    };
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Could not get a response.");
    conversation.push({role: "assistant", content: data.reply});
    addMessage("assistant", data.reply);
    $("providerStatus").textContent = data.provider === "demo" ? "Demo mode" : `${data.provider} AI`;
    setExpression(inferExpression(data.reply));
    if (voiceRepliesEnabled) speak(data.reply);
  } catch (err) {
    addMessage("assistant", `I couldn't connect to the AI right now. ${err.message} You can keep exploring the interface in demo mode.`);
    $("typingStatus").className = "error";
  } finally {
    if (!$("typingStatus").classList.contains("error")) $("typingStatus").textContent = "";
    $("sendButton").disabled = false;
  }
}
let voiceRepliesEnabled = localStorage.getItem("auraVoiceReplies") !== "off";
function populateVoices() {
  if (!("speechSynthesis" in window)) {
    $("voiceNote").textContent = "Speech synthesis isn't supported in this browser.";
    $("speechToggle").disabled = true;
    $("testVoice").disabled = true;
    return;
  }
  const select = $("voiceSelect");
  const previous = select.value;
  const voices = window.speechSynthesis.getVoices();
  select.replaceChildren(new Option("System default voice", ""));
  voices.forEach((voice, index) => select.appendChild(new Option(`${voice.name} (${voice.lang})`, String(index))));
  if (previous && [...select.options].some(o => o.value === previous)) select.value = previous;
  $("voiceNote").textContent = voices.length ? "Uses voices available on this device." : "Loading available voices…";
}
function updateSpeechToggle() {
  $("speechToggle").textContent = voiceRepliesEnabled ? "🔊 Voice replies: On" : "🔇 Voice replies: Off";
  $("speechToggle").classList.toggle("off", !voiceRepliesEnabled);
  $("speechToggle").setAttribute("aria-pressed", String(voiceRepliesEnabled));
}
function speak(text) {
  if (!("speechSynthesis" in window) || !voiceRepliesEnabled) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = Number($("speechRate").value || 1);
  utterance.pitch = Number($("speechPitch").value || 1);
  const chosen = $("voiceSelect").value;
  const voices = window.speechSynthesis.getVoices();
  if (chosen !== "" && voices[Number(chosen)]) utterance.voice = voices[Number(chosen)];
  utterance.onstart = () => { $("avatar").dataset.action = "talk"; };
  utterance.onend = () => { if ($("avatar").dataset.action === "talk") $("avatar").dataset.action = ""; };
  utterance.onerror = () => { $("avatar").dataset.action = ""; $("voiceNote").textContent = "Couldn't play this voice. Try another available voice."; };
  window.speechSynthesis.speak(utterance);
}
function setupVoice() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    $("voiceButton").addEventListener("click", () => alert("Speech recognition isn't available in this browser. Try a supported browser or type your message."));
    return;
  }
  recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => $("voiceButton").classList.add("active");
  recognition.onend = () => $("voiceButton").classList.remove("active");
  recognition.onerror = () => $("voiceButton").classList.remove("active");
  recognition.onresult = (event) => {
    $("messageInput").value = event.results[0][0].transcript;
    $("messageInput").focus();
  };
  $("voiceButton").addEventListener("click", () => {
    try { recognition.start(); } catch (_) { recognition.stop(); }
  });
}
document.querySelectorAll(".mood-option").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".mood-option").forEach(b => b.classList.remove("selected"));
    button.classList.add("selected");
    selectedMood = button.dataset.mood;
    $("moodSelected").textContent = `Your selected mood: ${selectedMood}`;
    const moodExpressions = {Happy: "happy", Okay: "calm", Stressed: "concerned", Sad: "concerned", "Not sure": "curious"};
    setExpression(moodExpressions[selectedMood]);
  });
});
$("sendButton").addEventListener("click", sendMessage);
$("messageInput").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
$("messageInput").addEventListener("input", e => {
  e.target.style.height = "auto";
  e.target.style.height = Math.min(e.target.scrollHeight, 130) + "px";
});
$("nameInput").addEventListener("input", applyName);
$("styleSelect").addEventListener("change", updateTheme);
$("expressionSelect").addEventListener("change", e => setExpression(e.target.value));
$("savePrefs").addEventListener("click", savePrefs);
$("clearChat").addEventListener("click", () => {
  if (confirm("Clear this conversation from the page?")) clearMessages();
});
$("privacyInfo").addEventListener("click", () => alert(
  "Privacy in this prototype:\\n\\n• Chat history stays in the current page and is not stored in a database.\\n• Appearance preferences are saved in this browser only.\\n• Demo mode does not send messages to an external AI provider.\\n• Online mode sends submitted messages to the provider configured by the project owner. Review that provider's privacy terms before using it.\\n• Do not enter passwords, financial details, or other highly sensitive information."
));
loadPrefs();
setupVoice();
populateVoices();
if ("speechSynthesis" in window) window.speechSynthesis.onvoiceschanged = populateVoices;
updateSpeechToggle();
$("speechToggle").addEventListener("click", () => {
  voiceRepliesEnabled = !voiceRepliesEnabled;
  localStorage.setItem("auraVoiceReplies", voiceRepliesEnabled ? "on" : "off");
  if (!voiceRepliesEnabled && "speechSynthesis" in window) window.speechSynthesis.cancel();
  updateSpeechToggle();
});
$("testVoice").addEventListener("click", () => {
  if (!("speechSynthesis" in window)) return alert("Spoken replies are not supported in this browser.");
  const previous = voiceRepliesEnabled;
  voiceRepliesEnabled = true;
  speak("Hello! I'm AURA, your AI companion. I'm ready to listen.");
  voiceRepliesEnabled = previous;
  updateSpeechToggle();
});
fetch("/api/health").then(r => r.json()).then(d => {
  $("providerStatus").textContent = d.provider === "demo" ? "Demo mode" : `${d.provider} configured`;
}).catch(() => $("providerStatus").textContent = "Local prototype");


