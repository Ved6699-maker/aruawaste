# Project AURA — Online AI Upgrade (existing project)

This package upgrades the existing AURA Human Actions starter rather than starting a new project. It keeps the chat interface, browser voice input/output, companion name/personality settings, masculine/feminine/androgynous styling, color themes, facial expressions, and simple CSS actions. It adds a ready-to-configure connection to Google's Gemini API using its OpenAI-compatible chat endpoint.

## What is included
- Online AI chat through Gemini once an API key is configured.
- Browser speech recognition where supported, plus browser text-to-speech.
- Customizable companion name, style, appearance theme, personality, and expressions.
- Simple wave, nod, dance, listen, and talking animations.
- API key stays in the server-side `.env` file and is not sent to the browser.

**Limitations:** Avatar styles and actions are CSS-based stylized animations, not photorealistic or full 3D avatars. Browser speech uses voices available on the user's device; it is not real-time human voice synthesis. Gemini API usage may be subject to free-tier quotas, eligibility, regional availability, and pricing.

## Windows setup
1. Extract this ZIP into a new folder.
2. Open that folder in File Explorer. Click the address bar, type `cmd`, and press Enter.
3. Run these commands one at a time:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
notepad .env
```

4. A Notepad window opens. Find `AI_API_KEY=PASTE_YOUR_GEMINI_API_KEY_HERE` and replace the placeholder with your Gemini API key. Do not add quotes unless the provider specifically requires them. Save and close Notepad.
5. Get the key from Google AI Studio: https://aistudio.google.com/apikey . Sign in, create an API key, and copy it. Review Google's current terms and usage limits before using it.
6. Start AURA:

```bat
python app.py
```

7. Open http://127.0.0.1:8000 in your browser. Keep the Command Prompt open while using AURA.

If you want to try the interface before configuring a key, change `AI_PROVIDER=online` to `AI_PROVIDER=demo` in `.env`; demo mode uses simple built-in responses and is not a full AI model. Change it back to `online` when the key is configured.

## Online AI configuration
The `.env.example` file is preconfigured for Google's Gemini OpenAI-compatible endpoint:

```ini
AI_PROVIDER=online
AI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai/
AI_API_KEY=your_key_here
AI_MODEL=gemini-3.8-flash
```

Model names can change; if this model is unavailable to your account, choose a currently available chat model in Google AI Studio and update `AI_MODEL`. Official docs: https://ai.google.dev/gemini-api/docs/openai/ .

## Troubleshooting
- **`'python' is not recognized`:** Install Python from https://www.python.org/downloads/windows/ and select the option to add Python to PATH during installation.
- **Online AI is not configured:** Check that you edited `.env`, saved it, and replaced the placeholder API key.
- **Provider error:** Confirm the key and model are valid, your internet connection works, and the account has API access/quota. The app intentionally hides raw provider errors and secrets.
- **Voice input not working:** Use a browser that supports the Web Speech recognition API and allow microphone permission. You can always type instead.
- **No spoken reply:** Check that Voice replies is On and try another voice in the selector.
- **Check app paths:** Visit http://127.0.0.1:8000/api/health and http://127.0.0.1:8000/debug/files .

## Privacy and safety
- The chat history is held in the current page and is not saved to a database by this starter. Appearance preferences are stored in local browser storage.
- When online mode is enabled, submitted conversation messages are sent to the configured AI provider. Read the provider's current privacy and data terms.
- Never publish your `.env` file or put your API key in `static/app.js`, HTML, a public GitHub repository, or a screenshot. If you accidentally expose a key, revoke it and create another.
- AURA is a supportive companion prototype, not a therapist or emergency service. Before public deployment, add authentication, rate limiting, consent, a privacy policy, and a security review.

## Useful reference
- Google AI Studio API keys: https://aistudio.google.com/apikey
- Gemini OpenAI compatibility: https://ai.google.dev/gemini-api/docs/openai/
- Web Speech API overview: https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API
