import os
from pathlib import Path
from typing import Literal

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
load_dotenv(BASE_DIR / ".env")

app = FastAPI(title="Project AURA API", version="0.3.0")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=4000)


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=30)
    mood: str = Field(default="Not sure", max_length=80)
    companion_name: str = Field(default="Aura", max_length=40)
    personality: str = Field(default="Warm and supportive", max_length=80)


class ChatResponse(BaseModel):
    reply: str
    provider: str


SYSTEM_PROMPT = (
    "You are a supportive AI companion, not a human and not a therapist. "
    "Be warm, respectful, non-judgmental, and concise. Do not claim to know emotions with certainty. "
    "Ask thoughtful questions, do not diagnose, and respect the user's autonomy. "
    "For imminent danger, encourage contacting local emergency services and a trusted person."
)


def demo_reply(last_message: str, mood: str) -> str:
    lower = last_message.lower()
    if any(w in lower for w in ["suicide", "kill myself", "end my life", "hurt myself"]):
        return ("I'm really sorry you're going through this, and I'm glad you told me. If you're in immediate danger, "
                "please contact local emergency services and someone you trust who can stay with you. Are you in immediate danger right now?")
    if any(w in lower for w in ["sad", "upset", "terrible", "lonely", "cry", "bad day"]):
        return ("That sounds difficult. Thank you for telling me. Would you like to tell me what happened, "
                "or would it help more if we thought of one small next step together?")
    if any(w in lower for w in ["stress", "stressed", "anxious", "exam", "overwhelmed", "worried"]):
        return ("It sounds like there's a lot on your mind. Would you prefer a short grounding exercise, "
                "help making a simple plan, or space to talk it through?")
    if any(w in lower for w in ["happy", "excited", "finished", "completed", "proud", "great news"]):
        return "That's lovely to hear! What part of it feels most meaningful to you?"
    return f"I'm here to listen. You selected “{mood},” but only you can say what fits. What's on your mind?"


async def call_online(messages, req):
    base = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    key = os.getenv("AI_API_KEY", "").strip()
    model = os.getenv("AI_MODEL", "").strip()
    if not key or not model:
        raise HTTPException(503, "Online AI is not configured. Open .env, add your provider API key to AI_API_KEY, and set AI_MODEL. For the included Gemini setup, see README.md.")
    msgs = [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "system", "content": f"Companion name: {req.companion_name}; personality: {req.personality}; user-selected mood: {req.mood}."}]
    msgs.extend([m.model_dump() for m in messages])
    async with httpx.AsyncClient(timeout=45) as client:
        r = await client.post(base + "/chat/completions",
            headers={"Authorization": "Bearer " + key},
            json={"model": model, "messages": msgs, "temperature": 0.7})
    if r.status_code >= 400:
        raise HTTPException(502, "Online provider error. Check provider settings.")
    try:
        return r.json()["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, TypeError):
        raise HTTPException(502, "Unexpected response from online provider.")


async def call_ollama(messages, req):
    base = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
    model = os.getenv("AI_MODEL", "").strip()
    if not model:
        raise HTTPException(503, "Set AI_MODEL to a model installed in Ollama.")
    msgs = [{"role": "system", "content": SYSTEM_PROMPT + f"\nName: {req.companion_name}. Personality: {req.personality}. User-selected mood: {req.mood}."}]
    msgs.extend([m.model_dump() for m in messages])
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(base + "/api/chat", json={"model": model, "messages": msgs, "stream": False})
    if r.status_code >= 400:
        raise HTTPException(502, "Could not reach Ollama. Check it is running and the model is installed.")
    try:
        return r.json()["message"]["content"].strip()
    except (KeyError, TypeError):
        raise HTTPException(502, "Unexpected response from Ollama.")


@app.get("/")
async def index():
    return FileResponse(str(STATIC_DIR / "index.html"), media_type="text/html")


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "provider": os.getenv("AI_PROVIDER", "demo").lower(),
        "static_dir_exists": STATIC_DIR.exists(),
        "html_exists": (STATIC_DIR / "index.html").exists(),
        "css_exists": (STATIC_DIR / "styles.css").exists(),
        "js_exists": (STATIC_DIR / "app.js").exists(),
    }


@app.get("/debug/files")
async def debug_files():
    return {
        "app_path": str(BASE_DIR),
        "static_path": str(STATIC_DIR),
        "static_files": sorted(p.name for p in STATIC_DIR.iterdir()) if STATIC_DIR.exists() else [],
    }


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    provider = os.getenv("AI_PROVIDER", "demo").lower().strip()
    last = next((m.content for m in reversed(req.messages) if m.role == "user"), "")
    if not last:
        raise HTTPException(400, "Please send a user message.")
    if provider == "online":
        reply = await call_online(req.messages, req)
    elif provider == "ollama":
        reply = await call_ollama(req.messages, req)
    else:
        provider = "demo"
        reply = demo_reply(last, req.mood)
    return ChatResponse(reply=reply, provider=provider)
